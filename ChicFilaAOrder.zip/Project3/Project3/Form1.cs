﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project3
{
    public partial class project4 : Form
    {
        double TotalPrice;
        double TotalCalories;
        double TotalSodium;
        double TotalProtein;
        double TotalFat;

        
        public project4()
        {
            InitializeComponent();
        }

        private void project4_Load(object sender, EventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            TotalPrice = 0;
            TotalCalories = 0;
            TotalSodium = 0;
            TotalProtein = 0;
            TotalFat = 0;
            TotalPrice = 0;



            lbFullOrder.Items.Clear();
            tbTotal.Clear();
            tbCalories.Clear();
            tbFat.Clear();
            tbProtein.Clear();
            tbSodium.Clear(); 
            
        }

        private void picSandwich_Click(object sender, EventArgs e)
        {
            TotalPrice += 3.05;
            TotalCalories += 440;
            TotalSodium += 1350;
            TotalFat += 19;
            TotalProtein += 28;

            tbTotal.Text = TotalPrice.ToString("c");
            tbCalories.Text = TotalCalories.ToString();
            tbSodium.Text = TotalSodium.ToString();
            tbFat.Text = TotalFat.ToString();
            tbProtein.Text = TotalProtein.ToString();

            lbFullOrder.Items.Add("Chicken Sandwich $3.05" ); 
        }

        private void lbFullOrder_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void picNuggets_Click(object sender, EventArgs e)
        {
            TotalPrice += 4.45;
            TotalCalories += 260;
            TotalSodium += 980;
            TotalFat += 12;
            TotalProtein += 28;

            tbTotal.Text = TotalPrice.ToString("c");
            tbCalories.Text = TotalCalories.ToString();
            tbSodium.Text = TotalSodium.ToString();
            tbFat.Text = TotalFat.ToString();
            tbProtein.Text = TotalProtein.ToString();

            lbFullOrder.Items.Add("Nuggets $4.45");

        }

        private void picCola_Click(object sender, EventArgs e)
        {
            TotalPrice += 2.75;
            TotalCalories += 260;
            TotalSodium += 90;
            TotalFat += 0;
            TotalProtein += 0;

            tbTotal.Text = TotalPrice.ToString("c");
            tbCalories.Text = TotalCalories.ToString();
            tbSodium.Text = TotalSodium.ToString();
            tbFat.Text = TotalFat.ToString();
            tbProtein.Text = TotalProtein.ToString();

            lbFullOrder.Items.Add("Cola $2.75");

        }

        private void picDrp_Click(object sender, EventArgs e)
        {
            TotalPrice += 2.75;
            TotalCalories += 260;
            TotalSodium += 90;
            TotalFat += 0;
            TotalProtein += 0;

            tbTotal.Text = TotalPrice.ToString("c");
            tbCalories.Text = TotalCalories.ToString();
            tbSodium.Text = TotalSodium.ToString();
            tbFat.Text = TotalFat.ToString();
            tbProtein.Text = TotalProtein.ToString();

            lbFullOrder.Items.Add("Dr. Pepper $2.75");

        }

        private void picSalad_Click(object sender, EventArgs e)
        {
            TotalPrice += 7.19;
            TotalCalories += 330;
            TotalSodium += 670;
            TotalFat += 14;
            TotalProtein += 27;

            tbTotal.Text = TotalPrice.ToString("c");
            tbCalories.Text = TotalCalories.ToString();
            tbSodium.Text = TotalSodium.ToString();
            tbFat.Text = TotalFat.ToString();
            tbProtein.Text = TotalProtein.ToString();

            lbFullOrder.Items.Add("Salad $7.19");

        }

        private void picFries_Click(object sender, EventArgs e)
        {
            TotalPrice += 1.85;
            TotalCalories += 360;
            TotalSodium += 280;
            TotalFat += 18;
            TotalProtein += 5;

            tbTotal.Text = TotalPrice.ToString("c");
            tbCalories.Text = TotalCalories.ToString();
            tbSodium.Text = TotalSodium.ToString();
            tbFat.Text = TotalFat.ToString();
            tbProtein.Text = TotalProtein.ToString();

            lbFullOrder.Items.Add("Fries $1.85");

        }

        private void tbTotal_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void tbFat_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
