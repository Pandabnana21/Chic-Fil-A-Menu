﻿namespace Project3
{
    partial class project4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(project4));
            this.picSandwich = new System.Windows.Forms.PictureBox();
            this.picDrp = new System.Windows.Forms.PictureBox();
            this.picCola = new System.Windows.Forms.PictureBox();
            this.picFries = new System.Windows.Forms.PictureBox();
            this.picNuggets = new System.Windows.Forms.PictureBox();
            this.picSalad = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tbFat = new System.Windows.Forms.TextBox();
            this.tbProtein = new System.Windows.Forms.TextBox();
            this.tbSodium = new System.Windows.Forms.TextBox();
            this.tbCalories = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblSandwich = new System.Windows.Forms.Label();
            this.lblFries = new System.Windows.Forms.Label();
            this.lblSalad = new System.Windows.Forms.Label();
            this.lblNuggets = new System.Windows.Forms.Label();
            this.lblCola = new System.Windows.Forms.Label();
            this.lblDrp = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tbTotal = new System.Windows.Forms.TextBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.lbFullOrder = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.picSandwich)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDrp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCola)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFries)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNuggets)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSalad)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // picSandwich
            // 
            this.picSandwich.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picSandwich.BackgroundImage")));
            this.picSandwich.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picSandwich.Location = new System.Drawing.Point(23, 36);
            this.picSandwich.Name = "picSandwich";
            this.picSandwich.Size = new System.Drawing.Size(206, 138);
            this.picSandwich.TabIndex = 0;
            this.picSandwich.TabStop = false;
            this.picSandwich.Click += new System.EventHandler(this.picSandwich_Click);
            // 
            // picDrp
            // 
            this.picDrp.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picDrp.BackgroundImage")));
            this.picDrp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picDrp.Location = new System.Drawing.Point(485, 212);
            this.picDrp.Name = "picDrp";
            this.picDrp.Size = new System.Drawing.Size(100, 138);
            this.picDrp.TabIndex = 4;
            this.picDrp.TabStop = false;
            this.picDrp.Click += new System.EventHandler(this.picDrp_Click);
            // 
            // picCola
            // 
            this.picCola.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picCola.BackgroundImage")));
            this.picCola.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picCola.Location = new System.Drawing.Point(485, 36);
            this.picCola.Name = "picCola";
            this.picCola.Size = new System.Drawing.Size(100, 138);
            this.picCola.TabIndex = 5;
            this.picCola.TabStop = false;
            this.picCola.Click += new System.EventHandler(this.picCola_Click);
            // 
            // picFries
            // 
            this.picFries.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picFries.BackgroundImage")));
            this.picFries.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picFries.Location = new System.Drawing.Point(23, 212);
            this.picFries.Name = "picFries";
            this.picFries.Size = new System.Drawing.Size(206, 138);
            this.picFries.TabIndex = 6;
            this.picFries.TabStop = false;
            this.picFries.Click += new System.EventHandler(this.picFries_Click);
            // 
            // picNuggets
            // 
            this.picNuggets.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picNuggets.BackgroundImage")));
            this.picNuggets.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picNuggets.Location = new System.Drawing.Point(256, 36);
            this.picNuggets.Name = "picNuggets";
            this.picNuggets.Size = new System.Drawing.Size(206, 138);
            this.picNuggets.TabIndex = 7;
            this.picNuggets.TabStop = false;
            this.picNuggets.Click += new System.EventHandler(this.picNuggets_Click);
            // 
            // picSalad
            // 
            this.picSalad.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picSalad.BackgroundImage")));
            this.picSalad.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picSalad.Location = new System.Drawing.Point(256, 212);
            this.picSalad.Name = "picSalad";
            this.picSalad.Size = new System.Drawing.Size(206, 138);
            this.picSalad.TabIndex = 8;
            this.picSalad.TabStop = false;
            this.picSalad.Click += new System.EventHandler(this.picSalad_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox1.Controls.Add(this.tbFat);
            this.groupBox1.Controls.Add(this.tbProtein);
            this.groupBox1.Controls.Add(this.tbSodium);
            this.groupBox1.Controls.Add(this.tbCalories);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(23, 368);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(439, 109);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Nutrition Totals:";
            // 
            // tbFat
            // 
            this.tbFat.Location = new System.Drawing.Point(326, 56);
            this.tbFat.Name = "tbFat";
            this.tbFat.Size = new System.Drawing.Size(55, 22);
            this.tbFat.TabIndex = 25;
            this.tbFat.Text = "0";
            this.tbFat.TextChanged += new System.EventHandler(this.tbFat_TextChanged);
            // 
            // tbProtein
            // 
            this.tbProtein.Location = new System.Drawing.Point(241, 56);
            this.tbProtein.Name = "tbProtein";
            this.tbProtein.Size = new System.Drawing.Size(55, 22);
            this.tbProtein.TabIndex = 24;
            this.tbProtein.Text = "0";
            // 
            // tbSodium
            // 
            this.tbSodium.Location = new System.Drawing.Point(147, 56);
            this.tbSodium.Name = "tbSodium";
            this.tbSodium.Size = new System.Drawing.Size(55, 22);
            this.tbSodium.TabIndex = 23;
            this.tbSodium.Text = "0";
            // 
            // tbCalories
            // 
            this.tbCalories.Location = new System.Drawing.Point(42, 56);
            this.tbCalories.Name = "tbCalories";
            this.tbCalories.Size = new System.Drawing.Size(55, 22);
            this.tbCalories.TabIndex = 22;
            this.tbCalories.Text = "0";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(323, 27);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(48, 16);
            this.label11.TabIndex = 21;
            this.label11.Text = "Fat (G)";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(238, 27);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(71, 16);
            this.label10.TabIndex = 20;
            this.label10.Text = "Protein (G)";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(144, 27);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(84, 16);
            this.label9.TabIndex = 19;
            this.label9.Text = "Sodium (Mg)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(39, 27);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 16);
            this.label8.TabIndex = 18;
            this.label8.Text = "Calories";
            // 
            // lblSandwich
            // 
            this.lblSandwich.AutoSize = true;
            this.lblSandwich.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSandwich.Location = new System.Drawing.Point(43, 14);
            this.lblSandwich.Name = "lblSandwich";
            this.lblSandwich.Size = new System.Drawing.Size(164, 19);
            this.lblSandwich.TabIndex = 0;
            this.lblSandwich.Text = "Chicken Sandwich  $3.05";
            // 
            // lblFries
            // 
            this.lblFries.AutoSize = true;
            this.lblFries.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFries.Location = new System.Drawing.Point(61, 190);
            this.lblFries.Name = "lblFries";
            this.lblFries.Size = new System.Drawing.Size(124, 19);
            this.lblFries.TabIndex = 10;
            this.lblFries.Text = "Waffle Fries  $1.85";
            // 
            // lblSalad
            // 
            this.lblSalad.AutoSize = true;
            this.lblSalad.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalad.Location = new System.Drawing.Point(289, 190);
            this.lblSalad.Name = "lblSalad";
            this.lblSalad.Size = new System.Drawing.Size(138, 19);
            this.lblSalad.TabIndex = 11;
            this.lblSalad.Text = "Chicken Salad  $7.19";
            // 
            // lblNuggets
            // 
            this.lblNuggets.AutoSize = true;
            this.lblNuggets.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNuggets.Location = new System.Drawing.Point(289, 14);
            this.lblNuggets.Name = "lblNuggets";
            this.lblNuggets.Size = new System.Drawing.Size(158, 19);
            this.lblNuggets.TabIndex = 12;
            this.lblNuggets.Text = "Chicken Nuggets  $4.45";
            this.lblNuggets.Click += new System.EventHandler(this.label4_Click);
            // 
            // lblCola
            // 
            this.lblCola.AutoSize = true;
            this.lblCola.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCola.Location = new System.Drawing.Point(493, 14);
            this.lblCola.Name = "lblCola";
            this.lblCola.Size = new System.Drawing.Size(79, 19);
            this.lblCola.TabIndex = 13;
            this.lblCola.Text = "Cola  $2.75";
            // 
            // lblDrp
            // 
            this.lblDrp.AutoSize = true;
            this.lblDrp.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDrp.Location = new System.Drawing.Point(493, 190);
            this.lblDrp.Name = "lblDrp";
            this.lblDrp.Size = new System.Drawing.Size(82, 19);
            this.lblDrp.TabIndex = 14;
            this.lblDrp.Text = "Dr. P  $2.75";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(659, 15);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 18);
            this.label7.TabIndex = 16;
            this.label7.Text = "TOTAL:";
            // 
            // tbTotal
            // 
            this.tbTotal.BackColor = System.Drawing.Color.LemonChiffon;
            this.tbTotal.Location = new System.Drawing.Point(730, 13);
            this.tbTotal.Name = "tbTotal";
            this.tbTotal.Size = new System.Drawing.Size(100, 20);
            this.tbTotal.TabIndex = 17;
            this.tbTotal.TextChanged += new System.EventHandler(this.tbTotal_TextChanged);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(791, 437);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(85, 40);
            this.btnClose.TabIndex = 18;
            this.btnClose.Text = "&CLOSE";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(662, 437);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(94, 40);
            this.btnClear.TabIndex = 19;
            this.btnClear.Text = "&CLEAR";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // lbFullOrder
            // 
            this.lbFullOrder.FormattingEnabled = true;
            this.lbFullOrder.Location = new System.Drawing.Point(604, 36);
            this.lbFullOrder.Name = "lbFullOrder";
            this.lbFullOrder.Size = new System.Drawing.Size(236, 316);
            this.lbFullOrder.TabIndex = 20;
            this.lbFullOrder.SelectedIndexChanged += new System.EventHandler(this.lbFullOrder_SelectedIndexChanged);
            // 
            // project4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(888, 488);
            this.Controls.Add(this.lbFullOrder);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.tbTotal);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lblDrp);
            this.Controls.Add(this.lblCola);
            this.Controls.Add(this.lblNuggets);
            this.Controls.Add(this.lblSalad);
            this.Controls.Add(this.lblFries);
            this.Controls.Add(this.lblSandwich);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.picSalad);
            this.Controls.Add(this.picNuggets);
            this.Controls.Add(this.picFries);
            this.Controls.Add(this.picCola);
            this.Controls.Add(this.picDrp);
            this.Controls.Add(this.picSandwich);
            this.Name = "project4";
            this.Text = "Project 3";
            this.Load += new System.EventHandler(this.project4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picSandwich)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDrp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCola)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFries)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNuggets)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSalad)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picSandwich;
        private System.Windows.Forms.PictureBox picDrp;
        private System.Windows.Forms.PictureBox picCola;
        private System.Windows.Forms.PictureBox picFries;
        private System.Windows.Forms.PictureBox picNuggets;
        private System.Windows.Forms.PictureBox picSalad;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox tbFat;
        private System.Windows.Forms.TextBox tbProtein;
        private System.Windows.Forms.TextBox tbSodium;
        private System.Windows.Forms.TextBox tbCalories;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblSandwich;
        private System.Windows.Forms.Label lblFries;
        private System.Windows.Forms.Label lblSalad;
        private System.Windows.Forms.Label lblNuggets;
        private System.Windows.Forms.Label lblCola;
        private System.Windows.Forms.Label lblDrp;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbTotal;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.ListBox lbFullOrder;
    }
}

